import Navbar from "../components/Navbar";

const About = () => {
  return (
    <>
      <Navbar></Navbar>

      <div className="mx-8">
                <h1 className="text-3xl">
                    This is About Page...
                </h1>
            </div>

    </>

  );
};

export default About;